
function SetFont(font){
    document.querySelector('body').style.fontFamily = font;
};
function SetFontSize(fontSize){
    document.querySelector('body').style.fontSize = fontSize;
};

SetFont(localStorage.getItem("mainFont") || '"Times New Roman" , Times, serif ');
SetFontSize(localStorage.getItem("mainFontSize") ||"20px");
