
function getFontElement(font) {
	return document.getElementById("font-" + font);
}
function getFontSizeElement(fontSize) {
	return document.getElementById("font-" + fontSize);
}


getFontElement("serif").addEventListener("click", () => {
	localStorage.setItem("mainFont", '"Times New Roman", Times, serif');
	SetFont(localStorage.getItem("mainFont") || '"Times New Roman", Times, serif');
});

getFontElement("cursive").addEventListener("click", () => {
	localStorage.setItem("mainFont", "'Brush Script MT', cursive");
	SetFont(localStorage.getItem("mainFont") || "'Brush Script MT', cursive");
});

getFontElement("monospace").addEventListener("click", () => {
	localStorage.setItem("mainFont", "'Courier New', monospace");
	SetFont(localStorage.getItem("mainFont") || '"Times New Roman", Times, serif');
});
getFontSizeElement("15px").addEventListener("click", () => {
	localStorage.setItem("mainFontSize", "15px");
	SetFontSize(localStorage.getItem("mainFontSize") || "20px");
});

getFontSizeElement("30px").addEventListener("click", () => {
	localStorage.setItem("mainFontSize", "30px");
	SetFontSize(localStorage.getItem("mainFontSize") || "20px");
});

getFontSizeElement("60px").addEventListener("click", () => {
	localStorage.setItem("mainFontSize","60px");
	SetFontSize(localStorage.getItem("mainFontSize") || "20px");
});
